<?php

// Registra cpt evento
function crear_custom_post_type_eventos() {
    register_post_type( 'evento', [
        'labels' => [
            'name' => 'Eventos',
            'singular_name' => 'Evento',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Evento',
            'edit_item' => 'Editar Evento',
            'new_item' => 'Nuevo Evento',
            'view_item' => 'Ver Evento',
            'search_items' => 'Buscar Eventos',
            'not_found' => 'No se encontraron eventos',
            'not_found_in_trash' => 'No hay eventos en la papelera',
            'all_items' => 'Todos los Eventos',
            'menu_name' => 'Eventos'
        ],
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true, // Importante gestionar datos api
        'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'custom-fields'],
        'taxonomies' => ['categoria_evento'], // Usa taxonomia personalizada categoria_evento
        'rewrite' => ['slug' => 'eventos'],
        'menu_icon' => 'dashicons-hourglass'
    ]);
}
add_action( 'init', 'crear_custom_post_type_eventos' );

// Registra la taxonomia personalizada categoria_evento
function crear_taxonomia_categoria_evento() {
    register_taxonomy(
        'categoria_evento',
        'evento',
        array(
            'hierarchical' => false, // Non-hierarchical (like tags)
            'labels' => array(
                'name' => 'Categorías de Eventos',
                'singular_name' => 'Categoría de Evento',
                'search_items' => 'Buscar Categorías',
                'all_items' => 'Todas las Categorías',
                'edit_item' => 'Editar Categoría',
                'update_item' => 'Actualizar Categoría',
                'add_new_item' => 'Añadir Nueva Categoría',
                'new_item_name' => 'Nuevo Nombre de Categoría',
                'menu_name' => 'Categorías de Eventos'
            ),
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'show_in_rest' => true,
            'rewrite' => array('slug' => 'categoria-evento'),
        )
    );
}
add_action( 'init', 'crear_taxonomia_categoria_evento' );

// Crea campos acf asociados al cpt evento
if( function_exists('acf_add_local_field_group') ) {
    acf_add_local_field_group(array(
        'key' => 'group_eventos',
        'title' => 'Eventos',
        'fields' => array(
            array(
                'key' => 'field_fecha_evento',
                'label' => 'Fecha del evento',
                'name' => 'fecha_evento',
                'type' => 'date_picker',
                'wrapper' => array(
                    'width' => '25%',
                ),
            ),
            array(
                'key' => 'field_lugar_evento',
                'label' => 'Lugar del evento',
                'name' => 'lugar_evento',
                'type' => 'text',
                'wrapper' => array(
                    'width' => '25%',
                ),
            ),
            array(
                'key' => 'field_url_registro',
                'label' => 'Url de registro o entrada',
                'name' => 'url_registro',
                'type' => 'url',
                'wrapper' => array(
                    'width' => '25%',
                ),
            ),
            array(
                'key' => 'field_ponentes_evento',
                'label' => 'Ponentes del evento',
                'name' => 'ponentes_evento',
                'type' => 'text',
                'wrapper' => array(
                    'width' => '25%',
                ),
            ),
            array(
                'key' => 'field_imagen_evento',
                'label' => 'Imagen del evento',
                'name' => 'imagen_evento',
                'type' => 'image',
                'return_format' => 'url',
                'wrapper' => array(
                    'width' => '25%',
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'evento',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'layout' => 'no_box',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
    ));
}


// Expose acf fields rest api
function expose_acf_rest_api() {
    if ( function_exists( 'get_field' ) ) {
        register_rest_field('evento', 'acf', array(
            'get_callback' => function($post) {
                return get_fields($post['id']);
            },
            'update_callback' => null,
            'schema' => null,
        ));
    }
}
add_action('rest_api_init', 'expose_acf_rest_api');